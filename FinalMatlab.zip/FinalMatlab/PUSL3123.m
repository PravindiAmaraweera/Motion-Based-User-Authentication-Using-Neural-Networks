data = load('U01_Acc_TimeD_FreqD_FDay.mat');
disp(data);

% Assuming that Acc_TDFD_Feat_Vec is the feature matrix (36 samples x 131 features)
X = data.Acc_TDFD_Feat_Vec;  % Features

% Create synthetic labels for demonstration (e.g., alternating 0 and 1)
Y = mod(1:36, 2);  % Binary labels 

% Split the data into training and testing sets (80% for training, 20% for testing)
cv = cvpartition(length(Y), 'HoldOut', 0.2);  % 80-20 split

X_train = X(cv.training, :);  % Training features
Y_train = Y(cv.training);    % Training labels
X_test = X(cv.test, :);      % Testing features
Y_test = Y(cv.test);         % Testing labels

% Display the size of the splits
disp(['Training Set: ', num2str(size(X_train, 1)), ' samples']);
disp(['Testing Set: ', num2str(size(X_test, 1)), ' samples']);

% the feedforward neural network
hiddenLayerSize = 10;  % Number of neurons in the hidden layer (can be tuned later)
net = feedforwardnet(hiddenLayerSize);

% Transpose inputs and targets for the neural network
X_train_nn = X_train';  % Make inputs [131 features x 29 samples]
Y_train_nn = Y_train';  % Make targets [1 output x 29 samples]

% Create and train the feedforward neural network
hiddenLayerSize = 10;  % Number of neurons in the hidden layer
net = feedforwardnet(hiddenLayerSize);

% Check the sizes of the training data
disp(['Size of X_train: ', num2str(size(X_train))]);
disp(['Size of Y_train: ', num2str(size(Y_train))]);

% Ensure X_train is [features x samples] and Y_train is [1 x samples]
X_train_nn = X_train';  % Transpose to [131 x 29]
Y_train_nn = Y_train;   % Make sure Y_train is already [29 x 1]

% Check the dimensions before training
disp(['Size of X_train_nn: ', num2str(size(X_train_nn))]);
disp(['Size of Y_train_nn: ', num2str(size(Y_train_nn))]);

% Create and train the feedforward neural network
hiddenLayerSize = 10;  % Number of neurons in the hidden layer
net = feedforwardnet(hiddenLayerSize);

% Train the network
net = train(net, X_train_nn, Y_train_nn);

% Test the network
X_test_nn = X_test';  % Transpose test features to [131 x 7]
Y_pred = net(X_test_nn);  % Predict the labels for the test set

% Convert network output to binary (0 or 1)
Y_pred_binary = round(Y_pred);

% Display predicted labels
disp('Predicted Labels:');
disp(Y_pred_binary);

% Evaluate performance
accuracy = sum(Y_pred_binary == Y_test') / length(Y_test);  % Calculate accuracy
disp(['Accuracy: ', num2str(accuracy * 100), '%']);

% Confusion Matrix
confMat = confusionmat(Y_test, Y_pred_binary');
disp('Confusion Matrix:');
disp(confMat);


% Train the network again and capture the training progress
[net, tr] = train(net, X_train_nn, Y_train_nn);

% Plot the training error (loss) over epochs
figure;
subplot(1,2,1);
plot(tr.epoch, tr.perf, '-o');  % perf stores the performance at each epoch
title('Training Loss');
xlabel('Epochs');
ylabel('Loss');
grid on;

% Plot the training accuracy (Performance) over epochs
subplot(1,2,2);
plot(tr.epoch, tr.vperf, '-o');  % vperf stores validation performance at each epoch
title('Validation Loss (Accuracy)');
xlabel('Epochs');
ylabel('Validation Loss');
grid on;

% Confusion Matrix Visualization
figure;
confMat = confusionmat(Y_test, Y_pred_binary');
heatmap(confMat, 'Title', 'Confusion Matrix', 'XLabel', 'Predicted', 'YLabel', 'True');

% Visualizing the predicted vs actual labels
figure;
subplot(2,1,1);
plot(Y_test, 'bo-', 'MarkerFaceColor', 'b');  % Actual labels
title('Actual Labels');
subplot(2,1,2);
plot(Y_pred_binary', 'ro-', 'MarkerFaceColor', 'r');  % Predicted labels
title('Predicted Labels');

% Visualizing Training Loss vs Epochs
figure;
subplot(1,2,1);
plot(tr.epoch, tr.perf, '-o');  % 'perf' stores the training performance at each epoch
title('Training Loss');
xlabel('Epochs');
ylabel('Loss');
grid on;

% Visualizing Validation Loss vs Epochs
subplot(1,2,2);
plot(tr.epoch, tr.vperf, '-o');  % 'vperf' stores the validation performance at each epoch
title('Validation Loss');
xlabel('Epochs');
ylabel('Validation Loss');
grid on;

% Confusion Matrix Visualization
figure;
confMat = confusionmat(Y_test, Y_pred_binary');
heatmap(confMat, 'Title', 'Confusion Matrix', 'XLabel', 'Predicted', 'YLabel', 'True');

% Visualizing the Predicted vs Actual Labels
figure;
subplot(2,1,1);
plot(Y_test, 'bo-', 'MarkerFaceColor', 'b');  % Actual labels (blue)
title('Actual Labels');
subplot(2,1,2);
plot(Y_pred_binary', 'ro-', 'MarkerFaceColor', 'r');  % Predicted labels (red)
title('Predicted Labels');


% Perform PCA to reduce dimensionality
[coeff, score, ~, ~, explained] = pca(X_train);

% Display the variance explained by each principal component
disp('Explained Variance of each Principal Component:');
disp(explained);

% Choose the number of components to keep (e.g., 95% of the variance)
variance_threshold = 95;  % Keep components that explain 95% of the variance
cumulative_variance = cumsum(explained);
num_components = find(cumulative_variance >= variance_threshold, 1);

disp(['Number of components to keep: ', num2str(num_components)]);

% Reduce the feature space by selecting the top components
X_train_pca = score(:, 1:num_components);  % Reduced training features
X_test_pca = (X_test - mean(X_train)) * coeff(:, 1:num_components);  % Apply PCA transformation to test set

% Display new size of the reduced feature set
disp(['Size of X_train_pca: ', num2str(size(X_train_pca))]);

% Create a feedforward neural network with adjustable hyperparameters
hiddenLayerSize = 15;  % Try increasing the number of neurons
net = feedforwardnet(hiddenLayerSize, 'traingd');  % Using Gradient Descent ('traingd')

% Set custom training parameters
net.trainParam.lr = 0.01;  % Learning rate (can be adjusted)
net.trainParam.epochs = 500;  % Increase the number of epochs
net.trainParam.goal = 1e-5;  % Goal for training error

% Train the network with the PCA-reduced dataset
net = train(net, X_train_pca', Y_train_nn);

% Test the network
Y_pred_pca = net(X_test_pca');
Y_pred_binary_pca = round(Y_pred_pca);

% Evaluate performance
accuracy_pca = sum(Y_pred_binary_pca == Y_test') / length(Y_test);
disp(['Accuracy with PCA and Hyperparameter Tuning: ', num2str(accuracy_pca * 100), '%']);

% Confusion Matrix
confMat_pca = confusionmat(Y_test, Y_pred_binary_pca');
disp('Confusion Matrix after PCA and Tuning:');
disp(confMat_pca);

% Load the dataset for User 1 (Frequency Domain Features)
data = load('U01_Acc_FreqD_FDay.mat');  % Adjust the filename if necessary
X = data.Acc_FD_Feat_Vec;  % Now using the correct field name

% Number of features (131 in total)
num_features = size(X, 2);  % Number of features

% Intra-user variance: variance of each feature for each user (columns)
intra_variance = var(X, 0, 1);  % Variance of features across samples for User 1

% Display intra-user variance
disp('Intra-user variance for User 1:');
disp(intra_variance);

% Visualizing variance within and between features:
% Boxplot of features across samples for User 1
figure;
boxplot(X);
title('Boxplot of Features for User 1 (Frequency Domain)');
xlabel('Feature Index');
ylabel('Feature Value');

% PCA Visualization for User 1 to explore variance
[coeff, score, ~, ~, explained] = pca(X);

% Plot the cumulative variance explained by each principal component
figure;
plot(cumsum(explained), '-o');
title('Cumulative Explained Variance by Principal Components');
xlabel('Number of Principal Components');
ylabel('Cumulative Variance (%)');

% Plot the first two principal components to visualize data distribution
figure;
scatter(score(:,1), score(:,2), 50, 'filled');
title('PCA: User 1 Data in First Two Principal Components');
xlabel('Principal Component 1');
ylabel('Principal Component 2');
